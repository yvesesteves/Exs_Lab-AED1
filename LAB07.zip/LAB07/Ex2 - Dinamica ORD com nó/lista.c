#include <stdio.h> 
#include <stdlib.h>
#include "lista.h"

struct no {
    int info;
    struct no * prox;
};

/*
    Entrada: nenhuma
    Pré-Condição: nenhuma
    Processo: cria uma lista
    Saída: nenhuma
    Pós-Condição: uma lista vazia
*/

Lista cria_lista()
{
    //aloca nó cabeçalho
    Lista cab;
    cab = (Lista) malloc(sizeof(struct no));
    //coloca lista no estado de vazia
    if(cab!=NULL){//SÓ se alocação não falhar
        cab -> prox=NULL;
        cab -> info=0;
    }//opcional de guarda quantidade                
    
    return cab;
} 

/*
    Entrada: recebe a lista
    Pré-Condição: ter uma lista criada
    Processo: verifica se a lista está vazia
    Saída: 1 se lista vazia // 0 se não vazia
    Pós-Condição: nenhuma
*/

int lista_vazia(Lista lst){
    if(lst-> prox == NULL)
        return 1; // Lista vazia
    else
        return 0; // Lista não vazia
}

/*
    Entrada: ponteiro pra lista e um elemento
    Pré-Condição: ter uma lista criada e a lista estar alocada
    Processo: adiciona um elem na lista
    Saída: 0 se falha // 1 se sucesso 
    Pós-Condição: uma lista com um elemento a mais
*/

int insere_elem(Lista *lst,int elem){
    //aloca um novo nó
    Lista N =(Lista)malloc(sizeof(struct no));
    if(N == NULL)
        return 0; // falha nó naõ alocado
    //preenche os campos do novo nó
    N-> info = elem;//inser o conteúdo (valor do elem)
    // percorrimento da lista 
    Lista aux = *lst; // faz aux apontar para nío cabeçalho
    while (aux -> prox != NULL && (aux->prox) ->info < elem)
        aux =aux  -> prox; // Avança
    // insere mo novo nó na lista
    N -> prox = aux -> prox;// aponta para o 1ºnó atual da lista
    aux -> prox = N;//faz o nó cabeçalho apontar para o novo nó
    (*lst) -> info++;//opcional para incrementar qtde de nós na lista   
    return 1;
}

/*
    Entrada: ponteiro pra lista e um elemento a ser removido
    Pré-Condição: lista não estar vazia
    Processo: remover um elemento da lista
    Saída: 1 se sucesso // 0 se falha
    Pós-Condição: lista com 1 elem a menos
*/

int remove_elem(Lista *lst,int elem){
    if(lista_vazia (*lst)==1)
        return 0; // falha 
    Lista aux = *lst;// ponteiro auxiliar para o nó cabeçalho
    // percorrimento até achar o elem ou final de lista 
    while (aux -> prox != NULL && aux -> prox -> info < elem)
        aux = aux -> prox;
    if (aux -> prox == NULL || aux -> prox -> info > elem) // Trata final de lista
        return 0; // falha
    // remove elemento da lista
    Lista aux2 = aux -> prox; // aponta nó a ser removido 
    aux -> prox = aux2 -> prox; //retira nó da lista 
    free(aux2); //libera memoria alocada
    (*lst)-> info --; // opcional: decrementa qtde de nós na lista
    return 1;     
}

/*
    Entrada: endereço da lista
    Pré Condição: a lista nao deve estar vazia e deve estar alocada
    Processo: percorre a lista e a imprime
    Saída: nenhuma
    Pós Condição: nenhuma
*/

void obtem_valor_elem(Lista lst){
    if(lst==NULL||lista_vazia(lst))
        printf("\nA lista esta vazia.");

    else{
        Lista aux=lst;

        while(aux!=NULL){
            printf("%d\n",aux->info);
            aux = aux->prox;
        }
    }
}
