#include <stdio.h>
#include <stdlib.h>
#include "lista.h"


int main()
{
    Lista lst;
    int i=0; 
    int elem; 


    inicio:
    while(i!=5){

        printf(" \n-------------Menu-------------\n");
        printf(" Digite [1], para iniciar uma lista:\n");
        printf(" Digite [2], para iserir elementos na lista:\n");
        printf(" Digite [3], eliminar um elemento da lista:\n");
        printf(" Digite [4], para imprimir a lista:\n");
        printf(" Digite [5], para fechar o programa:\n");

        scanf("%d", &i);
        setbuf(stdin, NULL);
    
        
        switch (i){
            case 1:
                lst = cria_lista();
                cria_lista();   
            
            break;
            
            case 2:
                printf(" digite o elemento a ser inserido:\n");
                scanf("%d",&elem);
                
                if(insere_elem(&lst, elem) == 0)
                    printf("lista não alocada \n");
                
                break;
            
            case 3:
                printf(" digite um elemento a ser removido da lista:\n");
                scanf("%d",&elem);
                
                if(remove_elem(&lst,elem) == 0)
                    printf("falha ao remover elemento\n");
                break;
            case 4:
                obtem_valor_elem(lst);
                break;
            
            case 5:
                goto inicio;
        }

    }  
   return 0;
}
