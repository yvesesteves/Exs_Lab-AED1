#include <stdio.h>
#include <stdlib.h>
#include "bebidas.h"

void imprime_lista(Lista lst);

int main(){

    Lista lst;
    Bebidas bebi;

    int ativo = 0;
    int n, N;

    while(ativo != 5){

        printf("\n----------------------Menu----------------------\n");
        printf("[1] Cria lista\n");
        printf("[2] Inserir bebida na lista\n");
        printf("[3] Remover bebida da lista\n");
        printf("[4] Imprimir Lista\n");
        printf("[5] Sair\n");
        printf("--------------------------------------------\n");

        scanf("%d", &n);
        setbuf(stdin, NULL);

        switch(n){

            case 1:
                lst = cria_lista();

                if(lst == NULL){
                    printf("Falha na alocacao\n");
                    return -1;
                }

                printf("Lista criada.\n");
                break;

            case 2:
                printf("Digite a bebida que deseja adicionar: ");
                scanf("%s", &bebi.nome);

                printf("Digite o volume da bebida: ");
                scanf("%d", &bebi.volume);

                printf("Digite o preco da bebida: ");
                scanf("%f", &bebi.preco);

                if(insere_elem(&lst, bebi) == 0)
                    printf("Nao foi possivel adicionar.\n");  
                
                else
                    printf("A bebida %s foi incluida.\n", &bebi.nome);

                break;
            
            case 3:
                printf("Digite a bebida que deseja remover: ");
                scanf("%s", &bebi.nome);

                if(remove_elem(&lst, bebi.nome) == 0)
                    printf("Bebida %s nao encontrado.\n", &bebi.nome);

                else    
                    printf("A bebida %s foi removida.\n", &bebi.nome);

                break;
            
            case 4:
                imprime_lista(lst);
                break;


            case 5:
                ativo = 5;
                break;

            default:
                printf("opcao invalida!\n");
        }
    }

    return 0;
}


/*
    Entrada: endereço da lista
    Pré Condição: a lista nao deve estar vazia e deve estar alocada
    Processo: percorre a lista e a imprime
    Saída: nenhuma
    Pós Condição: nenhuma
*/

void obtem_valor_elem(Lista lst){
    if(lst==NULL||lista_vazia(lst))
        printf("\nA lista esta vazia.\n");

    else{
        Lista aux=lst;

        while(aux!=NULL){
            printf("%d\n",aux->info);
            aux = aux->prox;
        }
    }
}