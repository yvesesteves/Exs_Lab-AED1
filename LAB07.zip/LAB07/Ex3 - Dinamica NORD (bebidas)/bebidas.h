#ifndef BEBIDAS_H_INCLUDED
#define BEBIDAS_H_INCLUDED

typedef struct no *Lista;

struct bebidas{
    char nome[20];
    int volume;
    float preco;
};

typedef struct bebidas Bebidas;

Lista cria_lista();
int lista_vazia(Lista lst);
int insere_elem(Lista *lst,int elem);
int remove_elem(Lista *lst,int elem);

#endif