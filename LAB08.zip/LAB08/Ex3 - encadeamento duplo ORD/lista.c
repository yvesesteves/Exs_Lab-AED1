#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

struct no{
    int info;
    struct no *prox;
    struct no *ant;
};

/* 
Lista cria_lista()
    Entrada: nenhuma
    Pré-Condição: nenhuma
    Processo: cria uma lista
    Saída: nenhuma
    Pós-Condição: uma lista vazia
*/

Lista cria_lista(){
    return NULL;
}

/*
int lista_vazia(Lista lst)
    Entrada: recebe a lista
    Pré-Condição: ter uma lista criada
    Processo: verifica se a lista está vazia
    Saída: 1 se lista vazia // 0 se não vazia
    Pós-Condição: nenhuma
*/


int lista_vazia(Lista lst){
    if(lst == NULL)
        return 1;
    else
        return 0;
}

/*

*/

int insere_elem(Lista *lst, int elem){
    //Aloca um novo nó e preenche campo info
    Lista N = (Lista)malloc(sizeof(struct no));
    if(N==NULL)
        return 0;   // falha, nó nao alocado
    N->info = elem; // insre o conteudo (valor do elem)
    N->ant = NULL;  // nao tem antecessor do novo nó
    N->prox = *lst; // sucessor do novo nó recebe mesmo end. da lista
    
    if(lista_vazia(*lst) == 0)      // se lista NÃO vazia
        (*lst)->ant = N;    //faz o antecessor do 1ºnó ser o novo nó
    *lst = N;   // faz a lista apontar para o novo nó
    return 1;
}

/*

*/

int remove_elem(Lista *lst, int elem){
    if(lista_vazia(*lst))   // trata lista vazia
        return 0;
    Lista aux = *lst;   // faz aux apontar para 1º nó
    while(aux->prox != NULL && aux->info != elem)
        aux = aux->prox;
    if(aux->info =! elem)   // elem não esta na lista
        return 0;  
    if(aux->prox != NULL)
        (aux)->prox->ant = aux->ant;
    if(aux->ant != NULL)
        (aux)->ant->prox = aux->prox;
    if(aux == *lst)
        *lst = aux->prox;
    free(aux);
    
    return 1;
}

/*
    Entrada: endereço da lista
    Pré Condição: a lista nao deve estar vazia e deve estar alocada
    Processo: percorre a lista e a imprime
    Saída: nenhuma
    Pós Condição: nenhuma
*/

void obtem_valor_elem(Lista lst){
    if(lst==NULL||lista_vazia(lst))
        printf("\nA lista esta vazia.\n");

    else{
        Lista aux=lst->prox;

        while(aux!=NULL){
            printf("\n\n%d\n",aux->info);
            aux=aux->prox;
        }
    }
}