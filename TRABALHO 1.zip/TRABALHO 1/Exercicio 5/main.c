#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int main(){
    int elem,op,pos,tam;
    Lista lista=NULL;

    while (1){
        printf("\n---------------Menu---------------\n");
        printf(" Digite [1]: Criar uma lista;\n");
        printf(" Digite [2]: Inserir no inicio;\n");
        printf(" Digite [3]: Inserir no final;\n");
        printf(" Digite [4]: Mostrar a lista;\n");
        printf(" Digite [5]: Remover no inicio;\n");
        printf(" Digite [6]: Remover no final;\n");
        printf(" Digite [7]: Inserir um elemento em uma posicao especifica;\n");
        printf(" Digite [8]: Remover todos os elementos pares;\n");
        printf(" Digite [9]: Retorna o tamanho da lista;\n");
        printf(" Digite [10]: Remover o maior elemento;\n");
        printf(" Digite [11]: Encerrar o programa.\n");
        printf("\tInsira a operacao: ");
        scanf("%d",&op);
        printf("\n----------------------------------\n");
        if(op==11)
            break;

        switch(op){
            case 1:
                lista=cria_lista();
                printf("\nA lista foi criada com sucesso!");

                break;
            case 2:
                printf("\nInsira o elemento que deseja inserir no inicio: ");
                scanf("%d",&elem);
                if(insere_inicio(&lista,elem)==0)
                    printf("\nNao foi possivel inserir o elemento no inicio.");
                else
                    printf("\nO elemento foi inserido com sucesso!");

                break;
            case 3:
                printf("\nInsira o elemento que deseja inserir no final: ");
                scanf("%d",&elem);
                if(insere_final(&lista,elem)==0)
                    printf("\nNao foi possivel inserir o elemento no final.");
                else
                    printf("\nO elemento foi inserido com sucesso!");

                break;
            case 4:
                mostra_lista(lista);
                break;
            case 5:
                if(remove_inicio(&lista,&elem)==0)
                    printf("\nNao foi possivel remover o elemento do inicio.");
                else
                    printf("\nO elemento do inicio (%d) foi removido com sucesso!",elem);

                break;
            case 6:
                if(remove_final(&lista,&elem)==0)
                    printf("\nNao foi possivel remover o elemento do final.");
                else
                    printf("\nO elemento final (%d) foi removido com sucesso!",elem);

                break;
            case 7:
                printf("\nInsira a posicao que deseja inserir um elemento: ");
                scanf("%d",&pos);
                printf("\nInsira o elemento que deseja inserir na posicao %d: ",pos);
                scanf("%d",&elem);

                if(insere_elem_pos(&lista,pos,elem)==0)
                    printf("\nNao foi possivel inserir o elemento.");
                else
                    printf("\nO elemento foi inserido com sucesso!");

                break;
            case 8:
                if(remove_pares(&lista)==0)
                    printf("\nNao foi possivel remover.");
                else
                    printf("\nOs elementos pares foram removidos.");
                break;
            case 9:
                tam=tamanho_lista(lista);
                if(tam==-1)
                    printf("\nNao foi possivel verificar o tamanho da lista.");
                else
                    printf("\nTamanho da lista: %d.",tam);

                break;
            case 10:
                if(remove_maior(&lista)==0)
                    printf("\nNão foi possivel remover o maior elemento!\n");
                else
                    printf("\nMaior elemento removido!\n");
                break;
            default:
                printf("\n Insira os numeros de 1 a 11 para as operacoes.\n");
                break;
        }
    }

    return 1;
}
