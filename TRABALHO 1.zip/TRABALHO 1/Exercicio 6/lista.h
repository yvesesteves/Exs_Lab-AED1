#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

typedef struct no * Lista;

Lista cria_lista();
int insere_elemento (Lista *lst, int elem);
int remove_elemento (Lista *lst, int elem);
int remove_todos (Lista *lst, int elem);
void imprime_lista (Lista lst);
int remove_maior (Lista *lst);
int tamanho_lista(Lista lst);
int media_lista(Lista * lst);
Lista inverte_lista (Lista *lst);


#endif