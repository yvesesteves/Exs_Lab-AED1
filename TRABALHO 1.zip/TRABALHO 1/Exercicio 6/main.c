#include <stdio.h>
#include <stdlib.h>
#include "lista.h"


int main(){


    Lista lst=NULL, lst1=NULL;
    int x,elem;
    int op, pos, n, tam;
    float media;


    while(1){
        printf("\n---------------Menu---------------\n");
        printf("\n     O que deseja fazer?\n");
        printf("\n[1]: Manipular lista ;\n");
        printf("[2]: Encerrar o programa\n");
        scanf("%d",&op);
        setbuf(stdin, NULL);
        if(op==2)
            break;

        switch(op){
            case 1:
                while(1){
                    printf("\n[1] Criar lista\n");
                    printf("[2] Imprimir Lista\n");
                    printf("[3] Insere elemento\n");
                    printf("[4] Remove Elemento\n");
                    printf("[5] Tamanho da lista\n");
                    printf("[6] Remove maior\n");
                    printf("[7] Calcular media\n");
                    printf("[8] Remove ocorrrencias\n");
                    printf("[9] Voltar\n");
                    scanf("%d", &n);
                    setbuf(stdin, NULL);
                    if(n==9)
                        break;

                    switch(n){
                        case 1:
                            lst = cria_lista();
                            if(&lst == NULL){
                                printf("Lista ainda n�o foi criada\n");
                            }else
                                printf("Lista criada!\n");
                            break;

                        case 2:
                            imprime_lista(lst);

                         break;

                        case 3:
                            printf("\nDigite o elemento a ser inserido\n");
                            scanf("%d", &elem);
                            insere_elemento(&lst, elem);
                            break;

                        case 4:
                            printf("\nDigite o elemento a ser removido\n");
                            scanf("%d", &x);
                            remove_elemento(&lst, x);
                            printf("\nElemento removido\n");

                            break;

                        case 5:
                            tam=tamanho_lista(lst);
                            if(tam==-1)
                                printf("\nNao foi possivel verificar o tamanho da lista.");
                             else
                                printf("\nTamanho da lista: %d.",tam);
                            break;

                        case 6:
                            remove_maior(&lst);
                            printf("\nMaior elemento removido\n");
                            break;

                        case 7:
                            media = media_lista(&lst);
                            if(media == 0)
                                printf("Nao foi possivel calcular a media");
                            else
                                printf("A media da lista eh: %f", media);

                        case 8:
                             printf("Digite valor a ser removido e suas ocorrencias\n");
                             scanf("%d", &elem);
                             remove_todos(&lst,elem);
                             printf("Ocorrencias removidas\n");
                            break;

                        default:
                            printf("Opcao invalida, selecione uma opcao de 1 a 9\n");
                            break;
                    }

                }
                break;
            default:
                printf("\nInsira operacoes de 1 ou 2.");
                break;
        }
    }
    printf("\nObrigado\n");
    return 0;
}
