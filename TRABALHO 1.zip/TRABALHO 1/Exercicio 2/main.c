#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int main()
{
    Lista lst1=NULL,lst2=NULL,lst3=NULL;
    int qtd,pos,i,op,n;
    int elem, men, flag;

    while(1){
        printf("\n--------Menu--------\n");
        printf(" Digite [1]: para manipular a lista 1;\n");
        printf(" Digite [2]: para manipular a lista 2;\n");
        printf(" Digite [3]: para concatenar as duas listas\n");
        printf(" Digite [4] para sair\n");
        printf(" Opcao: ");
        scanf("%d",&op);
        setbuf(stdin, NULL);
        if(op==4)
            break;

        switch(op){
            case 1:
                while(1){
                    printf("\n\n[1] Criar lista 1\n");
                    printf("[2] Inserir um elemento na lista\n");
                    printf("[3] Remover um elemento na lista\n");
                    printf("[4] Imprimir Lista\n");
                    printf("[5] Mostrar o menor elemento da lista\n");
                    printf("[6] Mostrar tamanho da lista\n");
                    printf("[7] Voltar\n");
                    printf("Insira a operacao: ");
                    scanf("%d", &n);
                    setbuf(stdin, NULL);
                    if(n==7)
                        break;

                    switch(n){
                        case 1:
                            lst1 = criar_lista();
                            if(lst1 == NULL){
                                printf("Lista ainda não foi criada\n");
                            }else
                                printf("Lista criada!\n");
                        break;

                        case 2:
                            scanf("%d", &elem);
                            insere_ord(lst1, elem);
                            printf("\n\n Elemento inserido!\n");
                            if(lst1 == NULL)
                            printf("Erro ao inserir elemento\n");
                        break;
                            
                        case 3:
                            scanf("%d", &elem);
                            remove_ord(lst1, elem);
                            printf("\n\n Elemento removido!\n");
                        break;

                        case 4:
                            printf("\n-------------------------------------\n");
                            obtem_valor_elem(lst1);
                            printf("\n-------------------------------------\n");
                            break;

                        case 5:
                            men = retorna_menor(lst1);
                                printf("Menor elemento: %d", men);
                            break;

                        case 6:
                            printf("\nTamanho da lista: %d",tamanho_lista(lst1));
                            break;
                            

                        default:
                            printf("Opção inválida, selecione uma opção de 1 a 8\n");
                            break;
                    }

                }
                break;

            case 2:
                while(1){
                    printf("\n\n[1] Criar lista 2\n");
                    printf("[2] Inserir um elemento na lista\n");
                    printf("[3] Remover um elemento na lista\n");
                    printf("[4] Imprimir Lista\n");
                    printf("[5] Mostrar o menor elemento da lista\n");
                    printf("[6] Mostrar tamanho da lista\n");
                    printf("[7] Voltar\n");
                    printf("Insira a operacao: ");
                    scanf("%d", &n);
                    setbuf(stdin, NULL);
                    if(n==7)
                        break;

                    switch(n){
                        case 1:
                            lst2 = criar_lista();
                            if(lst2 == NULL){
                                printf("Lista ainda não foi criada\n");
                            }else
                                printf("Lista criada!\n");
                        break;

                        case 2:
                            scanf("%d", &elem);
                            insere_ord(lst2, elem);
                            printf("\n\n Elemento inserido!\n");
                            if(lst2 == NULL)
                            printf("Erro ao inserir elemento\n");
                        break;
                            
                        case 3:
                            scanf("%d", &elem);
                            remove_ord(lst2, elem);
                            printf("\n\n Elemento removido!\n");
                        break;

                        case 4:
                            printf("\n-------------------------------------\n");
                            obtem_valor_elem(lst2);
                            printf("\n-------------------------------------\n");
                            break;

                        case 5:
                            men = retorna_menor(lst2);
                                printf("Menor elemento: %d", men);
                            break;

                        case 6:
                            printf("\nTamanho da lista: %d",tamanho_lista(lst2));
                            break;

                        default:
                            printf("Opção inválida, selecione uma opção de 1 a 8\n");
                            break;
                    }

                }
                break;

            case 3:
            lst3=concatenar(lst1,lst2);
                if(lst3==NULL)
                    printf("\nNao foi possivel concatenar as duas listas.");
                else{
                    printf("\n---------Lista concatenada:---------\n");
                    obtem_valor_elem(lst3);
                    printf("\n-------------------------------------\n");
                }
                break;
            default:
                printf("\nInsira operacoes de 1 a 4.\n");
                break;
         }

    }
    return 0;
}
