#ifndef RACIONAL_H_INCLUDED
#define RACIONAL_H_INCLUDED



typedef struct no *Lista;
Lista cria_lista();
Lista intercala_lista(Lista lst, Lista lst2);
Lista inverter (Lista *lst);
int lista_vazia(Lista lst);
int insere_ord(Lista *lst, int elem);
int remove_ord (Lista *lst,int elem);
int remove_impares (Lista *lst);
int iguais(Lista lst, Lista lst2);
void tamanho_lista(Lista * lst);
void media_lista(Lista * lst);



#endif