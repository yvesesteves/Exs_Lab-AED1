#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#define max 10


typedef struct lista *Lista;

Lista criar_lista();
int lista_vazia(Lista lst);
int lista_cheia(Lista lst);
int insere_elem(Lista lst, int elem);
int remove_elem(Lista lst, int elem);
void obtem_valor_elem(Lista lst);
int tamanho_lista(Lista lst);
Lista concatenar(Lista lst1, Lista lst2);
int retorna_menor(Lista lst);
int ordena_lista(Lista lst);


#endif