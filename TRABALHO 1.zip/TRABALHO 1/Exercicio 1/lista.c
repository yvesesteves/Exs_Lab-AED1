#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
#define max 10


struct lista{
    int num[max];
    int Fim;
};


/*
Lista* criar_lista()

    Entrada: nenhuma
    Pré Condição: nenhuma
    Processo: colocar a lista na condição de vazia
    Saída: retorna a lista criada
    Pós Condição: criada uma lista vazia
*/

Lista criar_lista(){
    Lista lst;

    lst = (Lista)malloc(sizeof(struct lista));

    if(lst != NULL)
        lst -> Fim = 0;     // lista vazia

    return lst;
}

/*
int lista_vazia(Lista *lst)

    Entrada: recebe endereço da lista
    Pré Condição: nenhuma
    Processo: verificar se a lista esta vazia
    Saída: 1 - lista vazia // 0 - lista não vazia
    Pós Condição: nenhuma
*/

int lista_vazia(Lista lst){
    if(lst->Fim == 0)
        return 1;   // lista vazia
    else
        return 0;   // lista não vazia
}

/*
int lista_cheia(Lista *lst)

    Entrada: recebe endereço da lista
    Pré Condição: nenhuma
    Processo: verificar se a lista está cheia
    Saída: 1 se lista cheia // 0 se não
    Pós Condição: nenhuma
*/

int lista_cheia(Lista lst){
    if(lst->Fim == max)
        return 1;   // lista cheia
    else
        return 0;   // lista não cheia
}

/*
int insere_elem(Lista *lst, int elem)

    Entrada: recebe endereço da lista e um elem a ser inserado
    Pré Condição: lista não estar cheia
    Processo: inserir o elemento em um dos extremos
    Saída: 1 se sucesso // 0 se falha
    Pós Condição: a lista da entrada com um elem a mais
*/

int insere_elem(Lista lst,int elem){
    if(lst==NULL||lista_cheia(lst))
        return 0;

    lst->num[lst->Fim] = elem;
    lst->Fim++;

    return 1;
}

/*
remove_elem(Lista *lst, int elem)

    Entrada: endereço da lista e o elem a ser removido 
    Pré Condição: lista não estar vazia
    Processo: percorrer a lista a partir do primeiro elem até o
        elem desejado ou até o fim da lista e se o elem for encontrado, remover-o da lista
    Saída: 1 se sucesso // 0 falha
    Pós Condição: lista com 1 elem removido
*/

int remove_elem(Lista lst, int elem){
    if(lst==NULL||lista_vazia(lst))
        return 0;

    int i,aux=0;

    while(aux<lst->Fim&&lst->num[aux]!= elem)
        aux++;

    if(aux==lst->Fim)
        return 0;

    for(i=aux+1;i<lst->Fim;i++)
        lst->num[i-1] = lst->num[i];

    lst->Fim--;

    return 1;
}

/*
obtem_valor_elem(Lista *lst)

    Entrada: endereço da lista
    Pré Condição: a lista nao deve estar vazia e deve estar alocada
    Processo: percorre a lista e a imprime
    Saída: nenhuma
    Pós Condição: nenhuma
*/


void obtem_valor_elem(Lista lst){
    if(lst == NULL || lista_vazia(lst))
        printf("\nA lista esta vazia ou nao esta alocada");
    else{
        int aux;
        for(aux = 0; aux < lst->Fim; aux++)
            if(lst->num[aux] != '\0')
                printf("%d\n", lst->num[aux]);
    }

}


/*  
int retorna_menor(Lista lst)

    Entrada: uma lista
    Pré-condição: A lista deve estar alocada
    Processo: percorre a lista até achar o menor elemento da mesma e retorna a ele
    Saída: 1 se for sucesso ou 0 se for falha
    Pós-condição: valor do menor elemento na tela
*/

int retorna_menor(Lista lst){
    if(lst==NULL || lista_vazia(lst)==1)
        return 0; //falha
    int menor = 0, i;
    for(i=0; i < lst->Fim; i++){
        if(lst->num[i] < lst -> num[menor]){
            menor = i;
        }
    }
    return lst->num[menor];//sucesso
}

/*
int ordena_lista(Lista lst)

    Entrada: uma lista
    Pré Condição: lista estar alocada e nao estar vazia
    Processso: ordena a lista em ordem crescente com ajuda das funçoes remove elem e remove menor
    Saída: 1 se sucesso, 0 se falha
    Pós Condição: uma lista ordenada em ordem crescente de maneira correta
*/

int ordena_lista(Lista lst){
    if(lst == NULL || lista_vazia(lst)==1)
        return 0;   // falha
    int m;
    int tam = lst->Fim;
    Lista aux;
    aux = criar_lista();
    for(int i = 0; i < tam; i++){
        m = retorna_menor(lst);
        remove_elem(lst, m);
        insere_elem(aux, m);
    }
    for(int x=0; x < tam; x++)
        insere_elem(lst, aux->num[x]);
    
    obtem_valor_elem(lst);
    return 1;
}


/*  
tamanho_lista(Lista lst)
    
    Entrada: Uma lista
    Pré-condição: A lista deve estar alocada
    Processo: Verifica a pre-condicao, em seguida retorna o valor do fim da lista, que indica o tamanho.
    Saída: Retorna o tamanho da lista. -1 se a lista nao estiver alocada.
    Pós-condição: Nao deve retornar -1.
*/

int tamanho_lista(Lista lst){
    if(lst==NULL)
        return -1;

    return lst->Fim;
}


/*   
concatenar(Lista lst1, Lista lst2)

    Entrada: Duas listas
    Pré-condição: Ambas devem estar alocadas e nao vazias
    Processo: Verifica as pre-condicoes, em seguida cria uma nova lista. Percorre a
            primeira lista e insere seus elementos na nova lista, depois percorre a segunda
            lista e tambem insere seus elementos na nova lista. Em seguida retorna a lista.
    Saída: Retorna a lista concatenada
    Pós-condição: A nova lista deve ser diferente de NULL
*/

Lista concatenar(Lista lst1, Lista lst2){
    if(lst1==NULL||lst2==NULL||lista_vazia(lst1)||lista_vazia(lst2))
        return NULL;

    if((tamanho_lista(lst1)+tamanho_lista(lst2))>max)
        return NULL;

    Lista lst3=criar_lista();
    if(lst3==NULL)
        return NULL;
    int i;

    for(i=0;i<max;i++){
        if(lst1->num[i] !=0)
            if(insere_elem(lst3,lst1->num[i])==0)
                return NULL;
    }

    for(i=0;i<max;i++){
        if(lst2->num[i]!=0)
            if(insere_elem(lst3,lst2->num[i])==0)
                return NULL;
    }

    return lst3;
}

