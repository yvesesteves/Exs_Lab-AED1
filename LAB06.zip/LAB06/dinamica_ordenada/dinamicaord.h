#ifndef DINAMICAORD_H_INCLUDED
#define DINAMICAORD_H_INCLUDED

typedef struct no *Lista;

Lista criar_lista();
int lista_vazia(Lista lst);
int insere_ord(Lista *lst, int elem);
int remove_ord(Lista *lst, int elem);
void obtem_valor_elem(Lista lst);

#endif