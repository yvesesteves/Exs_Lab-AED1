#include <stdio.h>
#include <stdlib.h>
#include "dinamicaord.h"

struct no{
    int info;
    struct no *prox;
};

/*
    Entrada: nenhuma
    Pré-Condição: nenhuma
    Processo: cria uma lista
    Saída: nenhuma
    Pós-Condição: uma lista vazia
*/

Lista criar_lista(){
    //Lista *lst;
    return NULL;
}

/*
    Entrada: recebe a lista
    Pré-Condição: ter uma lista criada
    Processo: verifica se a lista está vazia
    Saída: 1 se lista vazia // 0 se não vazia
    Pós-Condição: nenhuma
*/

int lista_vazia(Lista lst){
    if (lst == NULL)
        return 1;   // lista vazia
    else
        return 0;   // lista não vazia
}

/*
    Entrada: ponteiro pra lista e um elemento
    Pré-Condição: ter uma lista criada e a lista estar alocada
    Processo: adiciona um elem na lista na ordem correta
    Saída: 0 se falha // 1 se sucesso 
    Pós-Condição: uma lista com um elemento ordenado a mais
*/

int insere_ord(Lista *lst, int elem){
    // Aloca um novo nó
    Lista N = (Lista)malloc(sizeof(struct no));
    if(N == NULL)
        return 0;       // falha, nó nao alocado
    N->prox = *lst;     // aponta para o primeiro no atual da lista
    *lst = N;           // faz a lista apontar para o novo nó
        return 1;
    
    //Percorrimento da lista (elem > primeiro no da lista)
    Lista aux = *lst;   // faz aux apontar para o primeiro nó
    while(aux->prox != NULL && aux->prox->info < elem)
        aux = aux->prox;    // avança

    //Insere o novo elem na lista
    N->prox = aux->prox;
    aux->prox = N;
        return 1;
}

/*
    Entrada: ponteiro pra lista e um elemento a ser removido
    Pré-Condição: lista não estar vazia e o elem nao ser menor que o 1º nó da lista
    Processo: remover um elemento da lista
    Saída: 1 se sucesso // 0 se falha
    Pós-Condição: lista com 1 elem a menos
*/

int remove_ord(Lista *lst, int elem){
    if(lista_vazia(*lst) == 1 || elem <(*lst)->info)
        return 0;   // falha ao remover
    Lista aux = *lst;   // ponteiro auxiliar para o primeiro nó
    
    // trata eleemnto = primeiro no da lista
    if(elem == (*lst)->info){
        *lst = aux->prox;    // lista aponta para o segundo nó
        free(aux);      // libera memoria alocada
        return 1;
    }

    //percorrimento até o final da lista, achar o elem ou nó maior
    while(aux->prox != NULL && aux->prox->info < elem)
        aux = aux->prox;
    if(aux->prox == NULL || aux->prox->info > elem)
        return 0;   // falha

    //remove o elem diferente do primeiro nó da lista
    Lista aux2 = aux->prox;     // aponta nó a ser removido
    aux->prox = aux2->prox;     // retira nó da lista
    free(aux2);     // libera memoria alocada
    return 1;
}


/*
    Entrada: endereço da lista
    Pré Condição: a lista nao deve estar vazia e deve estar alocada
    Processo: percorre a lista e a imprime
    Saída: nenhuma
    Pós Condição: nenhuma
*/

void obtem_valor_elem(Lista lst){
    if(lst==NULL || lista_vazia(lst))
        printf("\nA lista esta vazia\n");
    else{
        Lista aux = lst->prox;

        while(aux!=NULL){
            printf("\n%d", aux->info);
            aux=aux->prox;
        }
    }

}