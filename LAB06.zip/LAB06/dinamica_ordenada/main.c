#include <stdio.h>
#include <stdlib.h>
#include "dinamicaord.h"

int main(){
    int i;
    int ativo = 0;
    int elem;
    Lista lst;

    while (ativo != 6) {
        printf("\n--------Menu--------\n");
        printf(" Digite [1] para criar uma lista\n");
        printf(" Digite [2] para verificar se a lista esta vazia\n");
        printf(" Digite [3] inserir um elemento\n");
        printf(" Digite [4] para excluir um elemento\n");
        printf(" Digite [5] para imprimir a lista\n");
        printf(" Digite [6] para sair\n");
        printf(" Opcao: ");
        scanf("%d", &i);
        setbuf(stdin, NULL);

        switch(i) {
            case 1:
                lst = criar_lista();
                printf("Lista criada!");
            break;

            case 2:
                if(lista_vazia(lst) == 1) {
                    printf("A lista esta vazia");
                break;
                }
                else {
                    printf("A lista não esta vazia");
                }
            break;

            case 3:
                printf("Digite o elemento a ser inserido ");
                scanf("%d", &elem);
                if(insere_ord(&lst, elem)) {
                    printf("\nElemento inserido!\n");
                }
                else {
                    printf("Erro ao inserir elemento!");
                }
            break;

            case 4:
                printf("Digite o elemento a ser removido ");
                scanf("%d", &elem);
                if(remove_ord(&lst, elem)) {
                    printf("\nElemento removido!\n");
                }
                else {
                    printf("Erro ao remover elemento!\n");
                }
            break;

            case 5:
                obtem_valor_elem(lst);
            break;

            case 6:
                ativo = 6;
                printf("\n-----------Fim do programa!-----------\n");
            break;

            default:
                printf("\nOpcao invalida, digite uma opcao de 1 a 6\n");

        }
    }

    return 0;
}