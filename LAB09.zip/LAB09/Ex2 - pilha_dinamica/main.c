#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"


int main(){
    Pilha p;
    int ativo = 0;
    int i;
    int elem;
    int top;
    
    while(ativo != 6){
        printf("\n----------------Menu---------------\n");
        printf("\nDigite [1] para criar a pilha\n");
        printf("Digite [2] para empilhar um elemento na pilha\n");
        printf("Digite [3] para desempilhar um elemento da pilha \n");
        printf("Digite [4] para imprimir a pilha\n");
        printf("Digite [5] para ler elemento do topo da pilha\n");
        printf("Digite [6] para sair\n");
    
        printf(" Opcao: ");
        scanf("%d", &i);
        setbuf(stdin, NULL);

    switch(i){
        case 1:
            p = cria_pilha();
            printf("Pilha criada!\n");
        break;
            
        case 2:
            scanf("%d", &elem);
            push(&p, elem);
            printf("Elemento empilhado!\n");
            if(p == NULL)
                printf("Erro ao empilhar elemento\n");
            break;
            

        case 3:
            pop(&p, &elem);
            printf("Elemento desempilhado!\n");
            break;

        case 4:
                printf("\n--------------------------\n");
                imprime_pilha(p);
                printf("\n--------------------------\n");
        break;

        case 5:
            le_topo(&p, &elem);
            printf("O topo da pilha eh: %d", elem);
            printf("\n");
        break;

        case 6:
            ativo = 6;
        break;

        default:
            printf("Opcao invalida, digite uma opcao de 1 a 8\n");
    }
    }


    return 0;
}